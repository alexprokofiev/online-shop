# Middleware Author's Guide

## What Is A Middleware?

## Middleware Traits

## Understanding Body Types

## Best Practices

## Error Propagation

## When To (Not) Use Middleware

## Author's References

- `EitherBody` + when is middleware appropriate: https://discord.com/channels/771444961383153695/952016890723729428

# Version 0.5.0

- **Breaking:** Bump `event-listener` to v5.0.0. (#12)
- Bump MSRV to 1.60. (#14)
- Make `NonBlocking` `Send` and `Sync`. (#15)

# Version 0.4.0

- **Breaking:** Bump `event-listener` to v4.0.0. (#10)

# Version 0.3.0

- **Breaking:** Remove an unneeded lifetime from the public API. (#6)

# Version 0.2.0

- **Breaking:** Add support for WASM targets by disabling `wait()` on them. (#3)

# Version 0.1.0

- Initial version

